import React, { createContext, useContext, useReducer, ReactNode } from 'react';

interface HealthCondition {
  id: string;
  name: string;
  restrictions: string[];
}

interface Allergen {
  id: string;
  name: string;
  severity: 'mild' | 'moderate' | 'severe';
}

interface Guest {
  id: string;
  name: string;
  room: string;
  healthConditions: HealthCondition[];
  allergens: Allergen[];
  dietaryPreferences: string[];
}

interface MenuItem {
  id: string;
  name: string;
  description: string;
  category: string;
  allergens: string[];
  nutritionInfo: {
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
    sodium: number;
  };
  healthFriendly: string[];
  imageUrl: string;
  price: number;
}

interface Order {
  id: string;
  guestId: string;
  guestName: string;
  room: string;
  items: MenuItem[];
  specialRequests: string;
  status: 'pending' | 'preparing' | 'ready' | 'delivered';
  timestamp: Date;
  allergenAlerts: string[];
}

interface Notification {
  id: string;
  type: 'info' | 'warning' | 'error' | 'success';
  title: string;
  message: string;
  timestamp: Date;
  dismissed: boolean;
}

interface AppState {
  guests: Guest[];
  menuItems: MenuItem[];
  orders: Order[];
  notifications: Notification[];
  currentGuest: Guest | null;
}

type AppAction =
  | { type: 'SET_CURRENT_GUEST'; payload: Guest }
  | { type: 'ADD_ORDER'; payload: Order }
  | { type: 'UPDATE_ORDER_STATUS'; payload: { id: string; status: Order['status'] } }
  | { type: 'ADD_NOTIFICATION'; payload: Notification }
  | { type: 'DISMISS_NOTIFICATION'; payload: string }
  | { type: 'UPDATE_GUEST_PROFILE'; payload: Guest };

const initialState: AppState = {
  guests: [
    {
      id: '1',
      name: 'Sarah Johnson',
      room: '302',
      healthConditions: [
        { id: '1', name: 'Type 2 Diabetes', restrictions: ['low-sugar', 'complex-carbs'] }
      ],
      allergens: [
        { id: '1', name: 'Shellfish', severity: 'severe' }
      ],
      dietaryPreferences: ['vegetarian']
    },
    {
      id: '2',
      name: 'Michael Chen',
      room: '115',
      healthConditions: [
        { id: '2', name: 'Hypertension', restrictions: ['low-sodium', 'heart-healthy'] }
      ],
      allergens: [
        { id: '2', name: 'Peanuts', severity: 'severe' }
      ],
      dietaryPreferences: ['gluten-free']
    }
  ],
  menuItems: [
    {
      id: '1',
      name: 'Grilled Salmon with Quinoa',
      description: 'Fresh Atlantic salmon with herb-crusted quinoa and steamed vegetables',
      category: 'Main Course',
      allergens: ['fish'],
      nutritionInfo: { calories: 420, protein: 35, carbs: 28, fat: 18, sodium: 180 },
      healthFriendly: ['heart-healthy', 'low-sodium', 'high-protein'],
      imageUrl: 'https://images.pexels.com/photos/1199957/pexels-photo-1199957.jpeg',
      price: 28
    },
    {
      id: '2',
      name: 'Mediterranean Vegetable Bowl',
      description: 'Roasted vegetables with chickpeas, feta, and tahini dressing',
      category: 'Main Course',
      allergens: ['dairy', 'sesame'],
      nutritionInfo: { calories: 380, protein: 15, carbs: 45, fat: 16, sodium: 320 },
      healthFriendly: ['vegetarian', 'mediterranean', 'fiber-rich'],
      imageUrl: 'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg',
      price: 24
    },
    {
      id: '3',
      name: 'Grass-Fed Beef Tenderloin',
      description: 'Premium beef with roasted root vegetables and red wine reduction',
      category: 'Main Course',
      allergens: ['sulphites'],
      nutritionInfo: { calories: 520, protein: 42, carbs: 12, fat: 32, sodium: 280 },
      healthFriendly: ['high-protein', 'keto-friendly'],
      imageUrl: 'https://images.pexels.com/photos/361184/asparagus-steak-veal-chop-veal-361184.jpeg',
      price: 45
    },
    {
      id: '4',
      name: 'Asian Fusion Tofu Stir-Fry',
      description: 'Organic tofu with seasonal vegetables in ginger-soy glaze',
      category: 'Main Course',
      allergens: ['soy', 'sesame'],
      nutritionInfo: { calories: 320, protein: 18, carbs: 35, fat: 12, sodium: 680 },
      healthFriendly: ['vegan', 'plant-based'],
      imageUrl: 'https://images.pexels.com/photos/1640772/pexels-photo-1640772.jpeg',
      price: 22
    }
  ],
  orders: [
    {
      id: '1',
      guestId: '1',
      guestName: 'Sarah Johnson',
      room: '302',
      items: [],
      specialRequests: 'Extra vegetables, no shellfish',
      status: 'preparing',
      timestamp: new Date(Date.now() - 30 * 60 * 1000),
      allergenAlerts: ['shellfish-free']
    }
  ],
  notifications: [],
  currentGuest: null
};

function appReducer(state: AppState, action: AppAction): AppState {
  switch (action.type) {
    case 'SET_CURRENT_GUEST':
      return { ...state, currentGuest: action.payload };
    case 'ADD_ORDER':
      return { ...state, orders: [...state.orders, action.payload] };
    case 'UPDATE_ORDER_STATUS':
      return {
        ...state,
        orders: state.orders.map(order =>
          order.id === action.payload.id
            ? { ...order, status: action.payload.status }
            : order
        )
      };
    case 'ADD_NOTIFICATION':
      return { ...state, notifications: [...state.notifications, action.payload] };
    case 'DISMISS_NOTIFICATION':
      return {
        ...state,
        notifications: state.notifications.map(n =>
          n.id === action.payload ? { ...n, dismissed: true } : n
        )
      };
    case 'UPDATE_GUEST_PROFILE':
      return {
        ...state,
        guests: state.guests.map(guest =>
          guest.id === action.payload.id ? action.payload : guest
        ),
        currentGuest: state.currentGuest?.id === action.payload.id ? action.payload : state.currentGuest
      };
    default:
      return state;
  }
}

const AppContext = createContext<{
  state: AppState;
  dispatch: React.Dispatch<AppAction>;
} | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(appReducer, initialState);

  return (
    <AppContext.Provider value={{ state, dispatch }}>
      {children}
    </AppContext.Provider>
  );
}

export function useAppContext() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useAppContext must be used within AppProvider');
  }
  return context;
}