import React, { useState, useEffect } from 'react';
import { AppProvider } from './context/AppContext';
import Navigation from './components/Navigation';
import GuestInterface from './components/GuestInterface';
import StaffDashboard from './components/StaffDashboard';
import AdminPanel from './components/AdminPanel';
import LandingPage from './components/LandingPage';
import NotificationSystem from './components/NotificationSystem';

function App() {
  const [currentView, setCurrentView] = useState<'landing' | 'guest' | 'staff' | 'admin'>('landing');

  return (
    <AppProvider>
      <div className="min-h-screen bg-gray-50">
        <NotificationSystem />
        
        {currentView !== 'landing' && (
          <Navigation currentView={currentView} onViewChange={setCurrentView} />
        )}
        
        {currentView === 'landing' && <LandingPage onViewChange={setCurrentView} />}
        {currentView === 'guest' && <GuestInterface />}
        {currentView === 'staff' && <StaffDashboard />}
        {currentView === 'admin' && <AdminPanel />}
      </div>
    </AppProvider>
  );
}

export default App;