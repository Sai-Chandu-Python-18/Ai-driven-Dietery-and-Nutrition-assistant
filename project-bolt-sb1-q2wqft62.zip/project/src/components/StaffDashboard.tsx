import React, { useState } from 'react';
import { useAppContext } from '../context/AppContext';
import KitchenDisplay from './staff/KitchenDisplay';
import OrderManagement from './staff/OrderManagement';
import GuestProfiles from './staff/GuestProfiles';
import SafetyMonitoring from './staff/SafetyMonitoring';
import { ChefHat, ClipboardList, Users, Shield, AlertTriangle, Clock, CheckCircle } from 'lucide-react';

export default function StaffDashboard() {
  const { state } = useAppContext();
  const [activeTab, setActiveTab] = useState<'kitchen' | 'orders' | 'guests' | 'safety'>('kitchen');

  const tabs = [
    { id: 'kitchen', label: 'Kitchen Display', icon: ChefHat, component: KitchenDisplay },
    { id: 'orders', label: 'Order Management', icon: ClipboardList, component: OrderManagement },
    { id: 'guests', label: 'Guest Profiles', icon: Users, component: GuestProfiles },
    { id: 'safety', label: 'Safety Monitoring', icon: Shield, component: SafetyMonitoring },
  ];

  const ActiveComponent = tabs.find(tab => tab.id === activeTab)?.component || KitchenDisplay;

  // Dashboard stats
  const pendingOrders = state.orders.filter(o => o.status === 'pending').length;
  const preparingOrders = state.orders.filter(o => o.status === 'preparing').length;
  const totalGuests = state.guests.length;
  const criticalAllergens = state.guests.reduce((acc, guest) => 
    acc + guest.allergens.filter(a => a.severity === 'severe').length, 0
  );

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Staff Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="bg-blue-100 p-3 rounded-full">
                <ChefHat className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Staff Dashboard</h1>
                <p className="text-gray-600">Kitchen operations & guest safety management</p>
              </div>
            </div>
            
            {/* Quick Stats */}
            <div className="flex items-center space-x-6">
              <div className="text-center">
                <div className="flex items-center space-x-2">
                  <Clock className="w-4 h-4 text-yellow-500" />
                  <span className="text-2xl font-bold text-gray-900">{pendingOrders}</span>
                </div>
                <p className="text-xs text-gray-600">Pending</p>
              </div>
              <div className="text-center">
                <div className="flex items-center space-x-2">
                  <ChefHat className="w-4 h-4 text-blue-500" />
                  <span className="text-2xl font-bold text-gray-900">{preparingOrders}</span>
                </div>
                <p className="text-xs text-gray-600">Preparing</p>
              </div>
              <div className="text-center">
                <div className="flex items-center space-x-2">
                  <Users className="w-4 h-4 text-green-500" />
                  <span className="text-2xl font-bold text-gray-900">{totalGuests}</span>
                </div>
                <p className="text-xs text-gray-600">Guests</p>
              </div>
              <div className="text-center">
                <div className="flex items-center space-x-2">
                  <AlertTriangle className="w-4 h-4 text-red-500" />
                  <span className="text-2xl font-bold text-gray-900">{criticalAllergens}</span>
                </div>
                <p className="text-xs text-gray-600">Critical Alerts</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="bg-white border-b border-gray-200 sticky top-16 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex space-x-8">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center space-x-2 py-4 border-b-2 transition-colors ${
                    activeTab === tab.id
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span className="font-medium">{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <ActiveComponent />
      </div>
    </div>
  );
}