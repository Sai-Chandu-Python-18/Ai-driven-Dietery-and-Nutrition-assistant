import React, { useState } from 'react';
import { useAppContext } from '../context/AppContext';
import { Settings, BarChart3, Users, Shield, Database, Bell, TrendingUp, Activity } from 'lucide-react';

export default function AdminPanel() {
  const { state } = useAppContext();
  const [activeTab, setActiveTab] = useState<'analytics' | 'settings' | 'compliance'>('analytics');

  // Calculate analytics
  const totalOrders = state.orders.length;
  const totalGuests = state.guests.length;
  const averageOrderTime = 18; // minutes
  const safetyIncidents = 0;
  const complianceScore = 98.5;

  const ordersByStatus = {
    pending: state.orders.filter(o => o.status === 'pending').length,
    preparing: state.orders.filter(o => o.status === 'preparing').length,
    ready: state.orders.filter(o => o.status === 'ready').length,
    delivered: state.orders.filter(o => o.status === 'delivered').length,
  };

  const allergenStats = state.guests.reduce((acc, guest) => {
    guest.allergens.forEach(allergen => {
      acc[allergen.name] = (acc[allergen.name] || 0) + 1;
    });
    return acc;
  }, {} as Record<string, number>);

  const healthConditionStats = state.guests.reduce((acc, guest) => {
    guest.healthConditions.forEach(condition => {
      acc[condition.name] = (acc[condition.name] || 0) + 1;
    });
    return acc;
  }, {} as Record<string, number>);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Admin Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="bg-purple-100 p-3 rounded-full">
                <Settings className="w-6 h-6 text-purple-600" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Admin Dashboard</h1>
                <p className="text-gray-600">System analytics, compliance monitoring, and configuration</p>
              </div>
            </div>
            
            {/* Quick Stats */}
            <div className="flex items-center space-x-6">
              <div className="text-center">
                <div className="flex items-center space-x-2">
                  <Activity className="w-4 h-4 text-green-500" />
                  <span className="text-2xl font-bold text-gray-900">{complianceScore}%</span>
                </div>
                <p className="text-xs text-gray-600">Compliance</p>
              </div>
              <div className="text-center">
                <div className="flex items-center space-x-2">
                  <TrendingUp className="w-4 h-4 text-blue-500" />
                  <span className="text-2xl font-bold text-gray-900">{totalOrders}</span>
                </div>
                <p className="text-xs text-gray-600">Total Orders</p>
              </div>
              <div className="text-center">
                <div className="flex items-center space-x-2">
                  <Shield className="w-4 h-4 text-red-500" />
                  <span className="text-2xl font-bold text-gray-900">{safetyIncidents}</span>
                </div>
                <p className="text-xs text-gray-600">Incidents</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="bg-white border-b border-gray-200 sticky top-16 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex space-x-8">
            {[
              { id: 'analytics', label: 'Analytics', icon: BarChart3 },
              { id: 'settings', label: 'System Settings', icon: Settings },
              { id: 'compliance', label: 'Compliance', icon: Shield },
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center space-x-2 py-4 border-b-2 transition-colors ${
                    activeTab === tab.id
                      ? 'border-purple-500 text-purple-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span className="font-medium">{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'analytics' && (
          <div className="space-y-6">
            {/* Analytics Header */}
            <div className="bg-gradient-to-r from-purple-600 to-indigo-600 text-white p-6 rounded-2xl">
              <h2 className="text-2xl font-bold mb-2">System Analytics</h2>
              <p className="text-purple-100">Comprehensive insights into system performance and usage</p>
            </div>

            {/* Key Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="bg-white p-6 rounded-xl border border-gray-200">
                <div className="flex items-center space-x-3">
                  <BarChart3 className="w-8 h-8 text-blue-500" />
                  <div>
                    <p className="text-2xl font-bold text-gray-900">{totalOrders}</p>
                    <p className="text-sm text-gray-600">Total Orders</p>
                  </div>
                </div>
                <div className="mt-2 text-xs text-green-600">↗ +12% from last week</div>
              </div>

              <div className="bg-white p-6 rounded-xl border border-gray-200">
                <div className="flex items-center space-x-3">
                  <Users className="w-8 h-8 text-green-500" />
                  <div>
                    <p className="text-2xl font-bold text-gray-900">{totalGuests}</p>
                    <p className="text-sm text-gray-600">Active Guests</p>
                  </div>
                </div>
                <div className="mt-2 text-xs text-green-600">↗ +8% from last week</div>
              </div>

              <div className="bg-white p-6 rounded-xl border border-gray-200">
                <div className="flex items-center space-x-3">
                  <Activity className="w-8 h-8 text-purple-500" />
                  <div>
                    <p className="text-2xl font-bold text-gray-900">{averageOrderTime}m</p>
                    <p className="text-sm text-gray-600">Avg Order Time</p>
                  </div>
                </div>
                <div className="mt-2 text-xs text-red-600">↗ +2m from last week</div>
              </div>

              <div className="bg-white p-6 rounded-xl border border-gray-200">
                <div className="flex items-center space-x-3">
                  <Shield className="w-8 h-8 text-red-500" />
                  <div>
                    <p className="text-2xl font-bold text-gray-900">{safetyIncidents}</p>
                    <p className="text-sm text-gray-600">Safety Incidents</p>
                  </div>
                </div>
                <div className="mt-2 text-xs text-green-600">↘ -100% from last week</div>
              </div>
            </div>

            {/* Charts */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Order Status Distribution */}
              <div className="bg-white p-6 rounded-xl border border-gray-200">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Order Status Distribution</h3>
                <div className="space-y-3">
                  {Object.entries(ordersByStatus).map(([status, count]) => (
                    <div key={status} className="flex items-center justify-between">
                      <span className="capitalize text-gray-700">{status}</span>
                      <div className="flex items-center space-x-2">
                        <div className="w-32 bg-gray-200 rounded-full h-2">
                          <div
                            className={`h-2 rounded-full ${
                              status === 'pending' ? 'bg-yellow-500' :
                              status === 'preparing' ? 'bg-blue-500' :
                              status === 'ready' ? 'bg-green-500' : 'bg-gray-500'
                            }`}
                            style={{ width: `${(count / totalOrders) * 100}%` }}
                          ></div>
                        </div>
                        <span className="text-sm font-medium text-gray-900">{count}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Allergen Statistics */}
              <div className="bg-white p-6 rounded-xl border border-gray-200">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Common Allergens</h3>
                <div className="space-y-3">
                  {Object.entries(allergenStats)
                    .sort(([,a], [,b]) => b - a)
                    .slice(0, 5)
                    .map(([allergen, count]) => (
                      <div key={allergen} className="flex items-center justify-between">
                        <span className="text-gray-700">{allergen}</span>
                        <div className="flex items-center space-x-2">
                          <div className="w-32 bg-gray-200 rounded-full h-2">
                            <div
                              className="h-2 rounded-full bg-red-500"
                              style={{ width: `${(count / totalGuests) * 100}%` }}
                            ></div>
                          </div>
                          <span className="text-sm font-medium text-gray-900">{count}</span>
                        </div>
                      </div>
                    ))}
                </div>
              </div>
            </div>

            {/* Health Conditions */}
            <div className="bg-white p-6 rounded-xl border border-gray-200">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Health Conditions Overview</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {Object.entries(healthConditionStats).map(([condition, count]) => (
                  <div key={condition} className="p-4 bg-blue-50 rounded-lg">
                    <h4 className="font-medium text-blue-900">{condition}</h4>
                    <p className="text-2xl font-bold text-blue-600">{count}</p>
                    <p className="text-sm text-blue-700">guests affected</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'settings' && (
          <div className="space-y-6">
            {/* Settings Header */}
            <div className="bg-gradient-to-r from-indigo-600 to-blue-600 text-white p-6 rounded-2xl">
              <h2 className="text-2xl font-bold mb-2">System Settings</h2>
              <p className="text-indigo-100">Configure system parameters and preferences</p>
            </div>

            {/* Settings Sections */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* AI Configuration */}
              <div className="bg-white p-6 rounded-xl border border-gray-200">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">AI Configuration</h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Recommendation Sensitivity
                    </label>
                    <select className="w-full p-2 border border-gray-300 rounded-lg">
                      <option>High (Conservative)</option>
                      <option selected>Medium (Balanced)</option>
                      <option>Low (Permissive)</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Allergen Detection Threshold
                    </label>
                    <input
                      type="range"
                      min="0"
                      max="100"
                      defaultValue="85"
                      className="w-full"
                    />
                    <div className="flex justify-between text-xs text-gray-500">
                      <span>Permissive</span>
                      <span>85%</span>
                      <span>Strict</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Notification Settings */}
              <div className="bg-white p-6 rounded-xl border border-gray-200">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Notification Settings</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-700">Real-time Alerts</span>
                    <input type="checkbox" defaultChecked className="rounded" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-700">Email Notifications</span>
                    <input type="checkbox" defaultChecked className="rounded" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-700">SMS Alerts</span>
                    <input type="checkbox" className="rounded" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-700">Push Notifications</span>
                    <input type="checkbox" defaultChecked className="rounded" />
                  </div>
                </div>
              </div>

              {/* Safety Protocols */}
              <div className="bg-white p-6 rounded-xl border border-gray-200">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Safety Protocols</h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Auto-Alert Timeout (minutes)
                    </label>
                    <input
                      type="number"
                      defaultValue="5"
                      className="w-full p-2 border border-gray-300 rounded-lg"
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-700">Require Staff Confirmation</span>
                    <input type="checkbox" defaultChecked className="rounded" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-700">Auto-Escalate Critical Alerts</span>
                    <input type="checkbox" defaultChecked className="rounded" />
                  </div>
                </div>
              </div>

              {/* Integration Settings */}
              <div className="bg-white p-6 rounded-xl border border-gray-200">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Integrations</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <p className="font-medium text-gray-900">Kitchen Display System</p>
                      <p className="text-sm text-gray-600">Connected</p>
                    </div>
                    <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <p className="font-medium text-gray-900">POS System</p>
                      <p className="text-sm text-gray-600">Connected</p>
                    </div>
                    <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <p className="font-medium text-gray-900">Health Apps Sync</p>
                      <p className="text-sm text-gray-600">Enabled</p>
                    </div>
                    <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'compliance' && (
          <div className="space-y-6">
            {/* Compliance Header */}
            <div className="bg-gradient-to-r from-green-600 to-teal-600 text-white p-6 rounded-2xl">
              <h2 className="text-2xl font-bold mb-2">Compliance Monitoring</h2>
              <p className="text-green-100">FDA, EU FIC, and industry standard compliance tracking</p>
            </div>

            {/* Compliance Score */}
            <div className="bg-white p-6 rounded-xl border border-gray-200">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-900">Overall Compliance Score</h3>
                <span className="text-3xl font-bold text-green-600">{complianceScore}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-4">
                <div
                  className="bg-green-500 h-4 rounded-full"
                  style={{ width: `${complianceScore}%` }}
                ></div>
              </div>
              <p className="text-sm text-gray-600 mt-2">Excellent compliance rating</p>
            </div>

            {/* Compliance Areas */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="bg-white p-6 rounded-xl border border-gray-200">
                <div className="flex items-center space-x-3 mb-4">
                  <Shield className="w-6 h-6 text-green-500" />
                  <h4 className="font-semibold text-gray-900">FDA Food Code</h4>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Allergen Labeling</span>
                    <span className="text-sm font-medium text-green-600">100%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Temperature Control</span>
                    <span className="text-sm font-medium text-green-600">98%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Cross-Contamination</span>
                    <span className="text-sm font-medium text-green-600">95%</span>
                  </div>
                </div>
              </div>

              <div className="bg-white p-6 rounded-xl border border-gray-200">
                <div className="flex items-center space-x-3 mb-4">
                  <Database className="w-6 h-6 text-blue-500" />
                  <h4 className="font-semibold text-gray-900">EU FIC Regulation</h4>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Ingredient Disclosure</span>
                    <span className="text-sm font-medium text-green-600">100%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Nutritional Info</span>
                    <span className="text-sm font-medium text-green-600">100%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Allergen Warnings</span>
                    <span className="text-sm font-medium text-green-600">100%</span>
                  </div>
                </div>
              </div>

              <div className="bg-white p-6 rounded-xl border border-gray-200">
                <div className="flex items-center space-x-3 mb-4">
                  <Bell className="w-6 h-6 text-purple-500" />
                  <h4 className="font-semibold text-gray-900">Industry Standards</h4>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">HACCP Compliance</span>
                    <span className="text-sm font-medium text-green-600">97%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Staff Training</span>
                    <span className="text-sm font-medium text-yellow-600">85%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Documentation</span>
                    <span className="text-sm font-medium text-green-600">100%</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Recent Audits */}
            <div className="bg-white p-6 rounded-xl border border-gray-200">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Compliance Audits</h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg">
                  <div>
                    <p className="font-medium text-green-900">FDA Inspection</p>
                    <p className="text-sm text-green-700">January 15, 2025</p>
                  </div>
                  <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm font-medium">
                    Passed
                  </span>
                </div>
                <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg">
                  <div>
                    <p className="font-medium text-green-900">Internal Safety Review</p>
                    <p className="text-sm text-green-700">January 10, 2025</p>
                  </div>
                  <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm font-medium">
                    Excellent
                  </span>
                </div>
                <div className="flex items-center justify-between p-4 bg-yellow-50 rounded-lg">
                  <div>
                    <p className="font-medium text-yellow-900">Staff Training Assessment</p>
                    <p className="text-sm text-yellow-700">January 5, 2025</p>
                  </div>
                  <span className="px-3 py-1 bg-yellow-100 text-yellow-800 rounded-full text-sm font-medium">
                    Needs Improvement
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}