import React, { useState } from 'react';
import { useAppContext } from '../context/AppContext';
import GuestLogin from './guest/GuestLogin';
import HealthProfile from './guest/HealthProfile';
import MenuBrowser from './guest/MenuBrowser';
import OrderHistory from './guest/OrderHistory';
import SafetyAlerts from './guest/SafetyAlerts';
import { User, Heart, Menu, Clock, Shield } from 'lucide-react';

export default function GuestInterface() {
  const { state } = useAppContext();
  const [activeTab, setActiveTab] = useState<'menu' | 'profile' | 'orders' | 'alerts'>('menu');

  if (!state.currentGuest) {
    return <GuestLogin />;
  }

  const tabs = [
    { id: 'menu', label: 'Menu', icon: Menu, component: MenuBrowser },
    { id: 'profile', label: 'Health Profile', icon: Heart, component: HealthProfile },
    { id: 'orders', label: 'My Orders', icon: Clock, component: OrderHistory },
    { id: 'alerts', label: 'Safety Alerts', icon: Shield, component: SafetyAlerts },
  ];

  const ActiveComponent = tabs.find(tab => tab.id === activeTab)?.component || MenuBrowser;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Guest Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="bg-emerald-100 p-3 rounded-full">
                <User className="w-6 h-6 text-emerald-600" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Welcome back, {state.currentGuest.name}</h1>
                <p className="text-gray-600">Room {state.currentGuest.room} • Personalized dining experience</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="bg-green-100 px-4 py-2 rounded-full">
                <span className="text-green-800 font-medium">Profile Active</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="bg-white border-b border-gray-200 sticky top-16 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex space-x-8">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center space-x-2 py-4 border-b-2 transition-colors ${
                    activeTab === tab.id
                      ? 'border-emerald-500 text-emerald-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span className="font-medium">{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <ActiveComponent />
      </div>
    </div>
  );
}