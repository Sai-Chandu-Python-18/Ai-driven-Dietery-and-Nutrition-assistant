import React from 'react';
import { Home, User, ChefHat, Settings, Utensils } from 'lucide-react';

interface NavigationProps {
  currentView: string;
  onViewChange: (view: 'landing' | 'guest' | 'staff' | 'admin') => void;
}

export default function Navigation({ currentView, onViewChange }: NavigationProps) {
  return (
    <nav className="bg-white border-b border-gray-200 sticky top-0 z-50 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-4">
            <button
              onClick={() => onViewChange('landing')}
              className="flex items-center space-x-2 text-gray-900 hover:text-emerald-600 transition-colors"
            >
              <div className="bg-emerald-500 p-1.5 rounded-lg">
                <Utensils className="w-5 h-5 text-white" />
              </div>
              <span className="font-semibold text-lg">NutriGuard AI</span>
            </button>
          </div>

          <div className="flex items-center space-x-6">
            <button
              onClick={() => onViewChange('guest')}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors ${
                currentView === 'guest'
                  ? 'bg-emerald-100 text-emerald-700'
                  : 'text-gray-600 hover:text-emerald-600 hover:bg-emerald-50'
              }`}
            >
              <User className="w-4 h-4" />
              <span>Guest Portal</span>
            </button>

            <button
              onClick={() => onViewChange('staff')}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors ${
                currentView === 'staff'
                  ? 'bg-blue-100 text-blue-700'
                  : 'text-gray-600 hover:text-blue-600 hover:bg-blue-50'
              }`}
            >
              <ChefHat className="w-4 h-4" />
              <span>Staff Dashboard</span>
            </button>

            <button
              onClick={() => onViewChange('admin')}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors ${
                currentView === 'admin'
                  ? 'bg-purple-100 text-purple-700'
                  : 'text-gray-600 hover:text-purple-600 hover:bg-purple-50'
              }`}
            >
              <Settings className="w-4 h-4" />
              <span>Admin Panel</span>
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}