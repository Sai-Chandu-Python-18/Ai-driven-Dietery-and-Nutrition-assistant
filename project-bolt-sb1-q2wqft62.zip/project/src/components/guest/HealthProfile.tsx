import React, { useState } from 'react';
import { useAppContext } from '../../context/AppContext';
import { Heart, AlertCircle, Plus, X, Save, Edit3 } from 'lucide-react';

export default function HealthProfile() {
  const { state, dispatch } = useAppContext();
  const [isEditing, setIsEditing] = useState(false);
  const [editedGuest, setEditedGuest] = useState(state.currentGuest);

  const commonHealthConditions = [
    { id: 'diabetes', name: 'Type 2 Diabetes', restrictions: ['low-sugar', 'complex-carbs', 'high-fiber'] },
    { id: 'hypertension', name: 'Hypertension', restrictions: ['low-sodium', 'heart-healthy', 'potassium-rich'] },
    { id: 'celiac', name: 'Celiac Disease', restrictions: ['gluten-free'] },
    { id: 'heart-disease', name: 'Heart Disease', restrictions: ['low-saturated-fat', 'heart-healthy', 'omega-3'] },
    { id: 'kidney-disease', name: 'Kidney Disease', restrictions: ['low-protein', 'low-phosphorus', 'low-potassium'] }
  ];

  const commonAllergens = [
    { id: 'nuts', name: 'Tree Nuts', severity: 'severe' },
    { id: 'peanuts', name: 'Peanuts', severity: 'severe' },
    { id: 'shellfish', name: 'Shellfish', severity: 'severe' },
    { id: 'dairy', name: 'Dairy', severity: 'moderate' },
    { id: 'eggs', name: 'Eggs', severity: 'moderate' },
    { id: 'gluten', name: 'Gluten', severity: 'moderate' },
    { id: 'soy', name: 'Soy', severity: 'mild' },
    { id: 'sesame', name: 'Sesame', severity: 'moderate' }
  ];

  const dietaryPreferences = [
    'vegetarian', 'vegan', 'pescatarian', 'keto', 'paleo', 'mediterranean', 'low-carb', 'high-protein'
  ];

  const saveProfile = () => {
    if (editedGuest) {
      dispatch({ type: 'UPDATE_GUEST_PROFILE', payload: editedGuest });
      setIsEditing(false);
      
      dispatch({
        type: 'ADD_NOTIFICATION',
        payload: {
          id: Date.now().toString(),
          type: 'success',
          title: 'Profile Updated',
          message: 'Your health profile has been successfully updated',
          timestamp: new Date(),
          dismissed: false
        }
      });
    }
  };

  const addHealthCondition = (condition: any) => {
    if (!editedGuest) return;
    
    const newCondition = {
      id: Date.now().toString(),
      name: condition.name,
      restrictions: condition.restrictions
    };
    
    setEditedGuest({
      ...editedGuest,
      healthConditions: [...editedGuest.healthConditions, newCondition]
    });
  };

  const removeHealthCondition = (id: string) => {
    if (!editedGuest) return;
    
    setEditedGuest({
      ...editedGuest,
      healthConditions: editedGuest.healthConditions.filter(c => c.id !== id)
    });
  };

  const addAllergen = (allergen: any) => {
    if (!editedGuest) return;
    
    const newAllergen = {
      id: Date.now().toString(),
      name: allergen.name,
      severity: allergen.severity as 'mild' | 'moderate' | 'severe'
    };
    
    setEditedGuest({
      ...editedGuest,
      allergens: [...editedGuest.allergens, newAllergen]
    });
  };

  const removeAllergen = (id: string) => {
    if (!editedGuest) return;
    
    setEditedGuest({
      ...editedGuest,
      allergens: editedGuest.allergens.filter(a => a.id !== id)
    });
  };

  const toggleDietaryPreference = (preference: string) => {
    if (!editedGuest) return;
    
    const preferences = editedGuest.dietaryPreferences.includes(preference)
      ? editedGuest.dietaryPreferences.filter(p => p !== preference)
      : [...editedGuest.dietaryPreferences, preference];
    
    setEditedGuest({
      ...editedGuest,
      dietaryPreferences: preferences
    });
  };

  if (!state.currentGuest) return null;

  const guest = isEditing ? editedGuest! : state.currentGuest;

  return (
    <div className="space-y-6">
      {/* Profile Header */}
      <div className="bg-gradient-to-r from-emerald-500 to-blue-500 text-white p-6 rounded-2xl">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="bg-white/20 p-3 rounded-full">
              <Heart className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-2xl font-bold">Health Profile</h2>
              <p className="text-emerald-100">Personalized dining recommendations based on your health needs</p>
            </div>
          </div>
          <button
            onClick={() => {
              if (isEditing) {
                saveProfile();
              } else {
                setIsEditing(true);
                setEditedGuest(state.currentGuest);
              }
            }}
            className="bg-white/20 hover:bg-white/30 px-4 py-2 rounded-lg transition-colors flex items-center space-x-2"
          >
            {isEditing ? <Save className="w-4 h-4" /> : <Edit3 className="w-4 h-4" />}
            <span>{isEditing ? 'Save Changes' : 'Edit Profile'}</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Health Conditions */}
        <div className="bg-white p-6 rounded-2xl border border-gray-200">
          <h3 className="text-xl font-semibold text-gray-900 mb-4 flex items-center space-x-2">
            <AlertCircle className="w-5 h-5 text-red-500" />
            <span>Health Conditions</span>
          </h3>

          <div className="space-y-3 mb-4">
            {guest.healthConditions.map((condition) => (
              <div key={condition.id} className="flex items-center justify-between p-3 bg-red-50 rounded-lg">
                <div>
                  <p className="font-medium text-gray-900">{condition.name}</p>
                  <p className="text-sm text-gray-600">
                    Restrictions: {condition.restrictions.join(', ')}
                  </p>
                </div>
                {isEditing && (
                  <button
                    onClick={() => removeHealthCondition(condition.id)}
                    className="text-red-500 hover:text-red-700"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>
            ))}
          </div>

          {isEditing && (
            <div>
              <h4 className="font-medium text-gray-900 mb-2">Add Health Condition</h4>
              <div className="grid grid-cols-1 gap-2">
                {commonHealthConditions
                  .filter(c => !guest.healthConditions.some(gc => gc.name === c.name))
                  .map((condition) => (
                    <button
                      key={condition.id}
                      onClick={() => addHealthCondition(condition)}
                      className="text-left p-2 border border-gray-200 rounded-lg hover:border-red-300 hover:bg-red-50 transition-colors flex items-center space-x-2"
                    >
                      <Plus className="w-4 h-4 text-red-500" />
                      <span>{condition.name}</span>
                    </button>
                  ))}
              </div>
            </div>
          )}
        </div>

        {/* Allergens */}
        <div className="bg-white p-6 rounded-2xl border border-gray-200">
          <h3 className="text-xl font-semibold text-gray-900 mb-4 flex items-center space-x-2">
            <AlertCircle className="w-5 h-5 text-orange-500" />
            <span>Allergens</span>
          </h3>

          <div className="space-y-3 mb-4">
            {guest.allergens.map((allergen) => (
              <div key={allergen.id} className="flex items-center justify-between p-3 bg-orange-50 rounded-lg">
                <div>
                  <p className="font-medium text-gray-900">{allergen.name}</p>
                  <div className="flex items-center space-x-2">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      allergen.severity === 'severe' 
                        ? 'bg-red-100 text-red-800'
                        : allergen.severity === 'moderate'
                        ? 'bg-orange-100 text-orange-800'
                        : 'bg-yellow-100 text-yellow-800'
                    }`}>
                      {allergen.severity}
                    </span>
                  </div>
                </div>
                {isEditing && (
                  <button
                    onClick={() => removeAllergen(allergen.id)}
                    className="text-red-500 hover:text-red-700"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>
            ))}
          </div>

          {isEditing && (
            <div>
              <h4 className="font-medium text-gray-900 mb-2">Add Allergen</h4>
              <div className="grid grid-cols-2 gap-2">
                {commonAllergens
                  .filter(a => !guest.allergens.some(ga => ga.name === a.name))
                  .map((allergen) => (
                    <button
                      key={allergen.id}
                      onClick={() => addAllergen(allergen)}
                      className="text-left p-2 border border-gray-200 rounded-lg hover:border-orange-300 hover:bg-orange-50 transition-colors flex items-center space-x-2"
                    >
                      <Plus className="w-4 h-4 text-orange-500" />
                      <span className="text-sm">{allergen.name}</span>
                    </button>
                  ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Dietary Preferences */}
      <div className="bg-white p-6 rounded-2xl border border-gray-200">
        <h3 className="text-xl font-semibold text-gray-900 mb-4 flex items-center space-x-2">
          <Heart className="w-5 h-5 text-emerald-500" />
          <span>Dietary Preferences</span>
        </h3>

        <div className="flex flex-wrap gap-3">
          {dietaryPreferences.map((preference) => {
            const isSelected = guest.dietaryPreferences.includes(preference);
            return (
              <button
                key={preference}
                onClick={() => isEditing && toggleDietaryPreference(preference)}
                disabled={!isEditing}
                className={`px-4 py-2 rounded-full font-medium transition-colors ${
                  isSelected
                    ? 'bg-emerald-500 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                } ${!isEditing && 'cursor-default'}`}
              >
                {preference}
              </button>
            );
          })}
        </div>
      </div>

      {/* AI Insights */}
      <div className="bg-gradient-to-r from-purple-500 to-pink-500 text-white p-6 rounded-2xl">
        <h3 className="text-xl font-semibold mb-4">AI Health Insights</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-white/20 p-4 rounded-lg">
            <h4 className="font-medium mb-2">Recommended Nutrients</h4>
            <ul className="text-sm space-y-1 text-purple-100">
              <li>• High fiber for digestive health</li>
              <li>• Omega-3 fatty acids for heart health</li>
              <li>• Antioxidants for immune support</li>
            </ul>
          </div>
          <div className="bg-white/20 p-4 rounded-lg">
            <h4 className="font-medium mb-2">Menu Compatibility</h4>
            <ul className="text-sm space-y-1 text-purple-100">
              <li>• 78% of menu items are safe for you</li>
              <li>• 12 dishes specifically recommended</li>
              <li>• 3 items flagged for allergen content</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}