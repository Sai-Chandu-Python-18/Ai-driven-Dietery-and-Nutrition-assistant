import React, { useState, useEffect } from 'react';
import { useAppContext } from '../../context/AppContext';
import { Shield, AlertTriangle, CheckCircle, Bell, Camera, Utensils } from 'lucide-react';

export default function SafetyAlerts() {
  const { state, dispatch } = useAppContext();
  const [buffetScan, setBuffetScan] = useState<any>(null);
  const [scanInProgress, setScanInProgress] = useState(false);

  // Simulate buffet scanning
  const simulateBuffetScan = () => {
    setScanInProgress(true);
    
    setTimeout(() => {
      const mockScanResult = {
        timestamp: new Date(),
        itemsScanned: [
          { name: 'Caesar Salad', allergens: ['dairy', 'eggs'], safe: false },
          { name: 'Grilled Vegetables', allergens: [], safe: true },
          { name: 'Seafood Pasta', allergens: ['shellfish', 'gluten'], safe: false },
          { name: 'Fruit Salad', allergens: [], safe: true },
          { name: 'Quinoa Bowl', allergens: [], safe: true }
        ]
      };
      
      setBuffetScan(mockScanResult);
      setScanInProgress(false);
      
      // Add notification for unsafe items
      const unsafeItems = mockScanResult.itemsScanned.filter(item => !item.safe);
      
      if (unsafeItems.length > 0) {
        dispatch({
          type: 'ADD_NOTIFICATION',
          payload: {
            id: Date.now().toString(),
            type: 'warning',
            title: 'Buffet Safety Alert',
            message: `${unsafeItems.length} items contain allergens that may not be safe for you`,
            timestamp: new Date(),
            dismissed: false
          }
        });
      }
    }, 3000);
  };

  const safetyTips = [
    {
      icon: Shield,
      title: 'Always Check Ingredient Lists',
      description: 'Review detailed ingredient information before ordering any dish.'
    },
    {
      icon: Bell,
      title: 'Enable Push Notifications',
      description: 'Get real-time alerts about menu changes and allergen warnings.'
    },
    {
      icon: Camera,
      title: 'Use Buffet Scanner',
      description: 'Scan buffet items with your phone camera for instant allergen detection.'
    },
    {
      icon: Utensils,
      title: 'Inform Your Server',
      description: 'Always let restaurant staff know about your dietary restrictions.'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Safety Header */}
      <div className="bg-gradient-to-r from-orange-500 to-red-500 text-white p-6 rounded-2xl">
        <div className="flex items-center space-x-3 mb-2">
          <Shield className="w-6 h-6" />
          <h2 className="text-2xl font-bold">Safety Center</h2>
        </div>
        <p className="text-orange-100">
          Real-time protection and alerts for your dietary safety
        </p>
      </div>

      {/* Current Safety Status */}
      <div className="bg-white p-6 rounded-2xl border border-gray-200">
        <h3 className="text-xl font-semibold text-gray-900 mb-4">Current Safety Status</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-green-50 p-4 rounded-lg border border-green-200">
            <div className="flex items-center space-x-3">
              <CheckCircle className="w-6 h-6 text-green-500" />
              <div>
                <p className="font-medium text-green-900">Profile Active</p>
                <p className="text-sm text-green-700">All restrictions loaded</p>
              </div>
            </div>
          </div>
          
          <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
            <div className="flex items-center space-x-3">
              <Bell className="w-6 h-6 text-blue-500" />
              <div>
                <p className="font-medium text-blue-900">Alerts Enabled</p>
                <p className="text-sm text-blue-700">Real-time notifications on</p>
              </div>
            </div>
          </div>
          
          <div className="bg-purple-50 p-4 rounded-lg border border-purple-200">
            <div className="flex items-center space-x-3">
              <Camera className="w-6 h-6 text-purple-500" />
              <div>
                <p className="font-medium text-purple-900">Scanner Ready</p>
                <p className="text-sm text-purple-700">Buffet detection active</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Buffet Scanner */}
      <div className="bg-white p-6 rounded-2xl border border-gray-200">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-semibold text-gray-900">Live Buffet Scanner</h3>
          <button
            onClick={simulateBuffetScan}
            disabled={scanInProgress}
            className={`px-4 py-2 rounded-lg font-medium transition-colors ${
              scanInProgress
                ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                : 'bg-purple-500 text-white hover:bg-purple-600'
            }`}
          >
            {scanInProgress ? 'Scanning...' : 'Scan Buffet Items'}
          </button>
        </div>

        {scanInProgress && (
          <div className="text-center py-8">
            <div className="animate-spin w-8 h-8 border-4 border-purple-200 border-t-purple-500 rounded-full mx-auto mb-4"></div>
            <p className="text-gray-600">Analyzing buffet items for allergens...</p>
          </div>
        )}

        {buffetScan && !scanInProgress && (
          <div className="space-y-4">
            <div className="bg-gray-50 p-4 rounded-lg">
              <p className="text-sm text-gray-600 mb-2">
                Last scan: {buffetScan.timestamp.toLocaleTimeString()}
              </p>
              <p className="font-medium text-gray-900">
                {buffetScan.itemsScanned.length} items analyzed
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {buffetScan.itemsScanned.map((item: any, index: number) => (
                <div
                  key={index}
                  className={`p-4 rounded-lg border-2 ${
                    item.safe
                      ? 'bg-green-50 border-green-200'
                      : 'bg-red-50 border-red-200'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className="font-medium text-gray-900">{item.name}</h4>
                      {item.allergens.length > 0 && (
                        <p className="text-sm text-gray-600 mt-1">
                          Contains: {item.allergens.join(', ')}
                        </p>
                      )}
                    </div>
                    {item.safe ? (
                      <CheckCircle className="w-5 h-5 text-green-500 mt-1" />
                    ) : (
                      <AlertTriangle className="w-5 h-5 text-red-500 mt-1" />
                    )}
                  </div>
                  <div className="mt-2">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      item.safe
                        ? 'bg-green-100 text-green-800'
                        : 'bg-red-100 text-red-800'
                    }`}>
                      {item.safe ? 'Safe for you' : 'Avoid - Contains allergens'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Your Restrictions */}
      <div className="bg-white p-6 rounded-2xl border border-gray-200">
        <h3 className="text-xl font-semibold text-gray-900 mb-4">Your Active Restrictions</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h4 className="font-medium text-gray-900 mb-3">Health Conditions</h4>
            <div className="space-y-2">
              {state.currentGuest?.healthConditions.map((condition) => (
                <div key={condition.id} className="flex items-center space-x-3 p-3 bg-blue-50 rounded-lg">
                  <AlertTriangle className="w-4 h-4 text-blue-500" />
                  <span className="text-blue-900 font-medium">{condition.name}</span>
                </div>
              ))}
            </div>
          </div>
          
          <div>
            <h4 className="font-medium text-gray-900 mb-3">Allergens</h4>
            <div className="space-y-2">
              {state.currentGuest?.allergens.map((allergen) => (
                <div key={allergen.id} className="flex items-center justify-between p-3 bg-red-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <AlertTriangle className="w-4 h-4 text-red-500" />
                    <span className="text-red-900 font-medium">{allergen.name}</span>
                  </div>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    allergen.severity === 'severe' 
                      ? 'bg-red-200 text-red-800'
                      : allergen.severity === 'moderate'
                      ? 'bg-orange-200 text-orange-800'
                      : 'bg-yellow-200 text-yellow-800'
                  }`}>
                    {allergen.severity}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Safety Tips */}
      <div className="bg-white p-6 rounded-2xl border border-gray-200">
        <h3 className="text-xl font-semibold text-gray-900 mb-4">Safety Tips</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {safetyTips.map((tip, index) => {
            const Icon = tip.icon;
            return (
              <div key={index} className="flex items-start space-x-4 p-4 bg-gray-50 rounded-lg">
                <div className="bg-emerald-100 p-2 rounded-lg">
                  <Icon className="w-5 h-5 text-emerald-600" />
                </div>
                <div>
                  <h4 className="font-medium text-gray-900 mb-1">{tip.title}</h4>
                  <p className="text-sm text-gray-600">{tip.description}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}