import React, { useState } from 'react';
import { useAppContext } from '../../context/AppContext';
import { User, Key, LogIn } from 'lucide-react';

export default function GuestLogin() {
  const { state, dispatch } = useAppContext();
  const [roomNumber, setRoomNumber] = useState('');
  const [guestName, setGuestName] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Find guest by room number or name
    const guest = state.guests.find(g => 
      g.room === roomNumber || g.name.toLowerCase().includes(guestName.toLowerCase())
    );

    if (guest) {
      dispatch({ type: 'SET_CURRENT_GUEST', payload: guest });
    } else {
      // For demo purposes, create a basic guest profile
      const newGuest = {
        id: Date.now().toString(),
        name: guestName || 'Guest User',
        room: roomNumber || '000',
        healthConditions: [],
        allergens: [],
        dietaryPreferences: []
      };
      dispatch({ type: 'SET_CURRENT_GUEST', payload: newGuest });
    }
  };

  const quickLogin = (guest: any) => {
    dispatch({ type: 'SET_CURRENT_GUEST', payload: guest });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-blue-50 flex items-center justify-center p-4">
      <div className="max-w-md w-full">
        <div className="bg-white rounded-2xl shadow-xl p-8">
          <div className="text-center mb-8">
            <div className="bg-emerald-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <User className="w-8 h-8 text-emerald-600" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900">Guest Portal</h2>
            <p className="text-gray-600 mt-2">Access your personalized dining experience</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Room Number
              </label>
              <div className="relative">
                <Key className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  value={roomNumber}
                  onChange={(e) => setRoomNumber(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                  placeholder="Enter your room number"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Guest Name
              </label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  value={guestName}
                  onChange={(e) => setGuestName(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                  placeholder="Enter your name"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-emerald-500 text-white py-3 rounded-lg font-semibold hover:bg-emerald-600 transition-colors flex items-center justify-center space-x-2"
            >
              <LogIn className="w-5 h-5" />
              <span>Access Portal</span>
            </button>
          </form>

          <div className="mt-8">
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-300" />
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-white text-gray-500">Quick Demo Access</span>
              </div>
            </div>

            <div className="mt-6 space-y-3">
              {state.guests.map((guest) => (
                <button
                  key={guest.id}
                  onClick={() => quickLogin(guest)}
                  className="w-full text-left p-4 border border-gray-200 rounded-lg hover:border-emerald-300 hover:bg-emerald-50 transition-colors"
                >
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="font-medium text-gray-900">{guest.name}</p>
                      <p className="text-sm text-gray-600">Room {guest.room}</p>
                    </div>
                    <div className="text-xs bg-gray-100 px-2 py-1 rounded">
                      {guest.healthConditions.length + guest.allergens.length} conditions
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}