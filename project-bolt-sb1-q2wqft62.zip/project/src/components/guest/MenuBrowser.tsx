import React, { useState, useMemo } from 'react';
import { useAppContext } from '../../context/AppContext';
import { Star, AlertTriangle, Check, Plus, Heart, Utensils } from 'lucide-react';

export default function MenuBrowser() {
  const { state, dispatch } = useAppContext();
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [cart, setCart] = useState<any[]>([]);

  const categories = ['All', 'Main Course', 'Appetizers', 'Desserts', 'Beverages'];

  const filteredMenuItems = useMemo(() => {
    const items = selectedCategory === 'All' 
      ? state.menuItems 
      : state.menuItems.filter(item => item.category === selectedCategory);

    // AI-powered personalization based on guest health profile
    if (state.currentGuest) {
      return items.map(item => {
        let score = 0;
        let recommendations = [];
        let warnings = [];

        // Check allergens
        const hasAllergens = state.currentGuest.allergens.some(allergen =>
          item.allergens.some(itemAllergen => 
            itemAllergen.toLowerCase().includes(allergen.name.toLowerCase())
          )
        );

        if (hasAllergens) {
          warnings.push('Contains allergens');
          score -= 10;
        }

        // Check health conditions
        state.currentGuest.healthConditions.forEach(condition => {
          condition.restrictions.forEach(restriction => {
            if (item.healthFriendly.includes(restriction)) {
              score += 5;
              recommendations.push(`Great for ${condition.name}`);
            }
          });
        });

        // Check dietary preferences
        state.currentGuest.dietaryPreferences.forEach(pref => {
          if (item.healthFriendly.includes(pref)) {
            score += 3;
            recommendations.push(`Matches ${pref} preference`);
          }
        });

        return {
          ...item,
          aiScore: score,
          recommendations,
          warnings,
          isRecommended: score > 0 && warnings.length === 0
        };
      }).sort((a, b) => b.aiScore - a.aiScore);
    }

    return items;
  }, [selectedCategory, state.menuItems, state.currentGuest]);

  const addToCart = (item: any) => {
    setCart([...cart, item]);
    
    // Add notification
    dispatch({
      type: 'ADD_NOTIFICATION',
      payload: {
        id: Date.now().toString(),
        type: 'success',
        title: 'Added to Order',
        message: `${item.name} has been added to your order`,
        timestamp: new Date(),
        dismissed: false
      }
    });
  };

  const placeOrder = () => {
    if (cart.length === 0) return;

    const order = {
      id: Date.now().toString(),
      guestId: state.currentGuest!.id,
      guestName: state.currentGuest!.name,
      room: state.currentGuest!.room,
      items: cart,
      specialRequests: 'AI-personalized order based on health profile',
      status: 'pending' as const,
      timestamp: new Date(),
      allergenAlerts: state.currentGuest!.allergens.map(a => a.name)
    };

    dispatch({ type: 'ADD_ORDER', payload: order });
    setCart([]);

    dispatch({
      type: 'ADD_NOTIFICATION',
      payload: {
        id: Date.now().toString(),
        type: 'success',
        title: 'Order Placed Successfully',
        message: `Your personalized order has been sent to the kitchen`,
        timestamp: new Date(),
        dismissed: false
      }
    });
  };

  return (
    <div className="space-y-6">
      {/* AI Insights Banner */}
      <div className="bg-gradient-to-r from-emerald-500 to-blue-500 text-white p-6 rounded-2xl">
        <div className="flex items-center space-x-3 mb-2">
          <Heart className="w-6 h-6" />
          <h3 className="text-xl font-semibold">AI-Personalized Menu</h3>
        </div>
        <p className="text-emerald-100">
          Meals are ranked based on your health profile: {state.currentGuest?.healthConditions.map(c => c.name).join(', ')} 
          {state.currentGuest?.allergens.length > 0 && ` • Avoiding: ${state.currentGuest.allergens.map(a => a.name).join(', ')}`}
        </p>
      </div>

      {/* Category Filter */}
      <div className="flex space-x-4 overflow-x-auto pb-2">
        {categories.map((category) => (
          <button
            key={category}
            onClick={() => setSelectedCategory(category)}
            className={`px-6 py-2 rounded-full font-medium whitespace-nowrap transition-colors ${
              selectedCategory === category
                ? 'bg-emerald-500 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            {category}
          </button>
        ))}
      </div>

      {/* Cart Summary */}
      {cart.length > 0 && (
        <div className="bg-white p-4 rounded-xl border border-emerald-200">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-semibold text-gray-900">Current Order</h4>
              <p className="text-sm text-gray-600">{cart.length} items • ${cart.reduce((sum, item) => sum + item.price, 0)}</p>
            </div>
            <button
              onClick={placeOrder}
              className="bg-emerald-500 text-white px-6 py-2 rounded-lg hover:bg-emerald-600 transition-colors"
            >
              Place Order
            </button>
          </div>
        </div>
      )}

      {/* Menu Items Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredMenuItems.map((item) => (
          <div
            key={item.id}
            className={`bg-white rounded-2xl overflow-hidden shadow-sm border-2 transition-all hover:shadow-lg ${
              item.isRecommended ? 'border-emerald-200 bg-emerald-50' : 'border-gray-100'
            }`}
          >
            {/* Item Image */}
            <div className="relative h-48 overflow-hidden">
              <img
                src={item.imageUrl}
                alt={item.name}
                className="w-full h-full object-cover"
              />
              {item.isRecommended && (
                <div className="absolute top-3 left-3 bg-emerald-500 text-white px-3 py-1 rounded-full text-sm font-medium flex items-center space-x-1">
                  <Star className="w-4 h-4 fill-current" />
                  <span>AI Recommended</span>
                </div>
              )}
              {item.warnings.length > 0 && (
                <div className="absolute top-3 right-3 bg-red-500 text-white p-2 rounded-full">
                  <AlertTriangle className="w-4 h-4" />
                </div>
              )}
            </div>

            {/* Item Content */}
            <div className="p-6">
              <div className="flex items-start justify-between mb-3">
                <h3 className="text-xl font-semibold text-gray-900">{item.name}</h3>
                <span className="text-xl font-bold text-emerald-600">${item.price}</span>
              </div>
              
              <p className="text-gray-600 mb-4">{item.description}</p>

              {/* AI Recommendations */}
              {item.recommendations.length > 0 && (
                <div className="mb-4 space-y-1">
                  {item.recommendations.map((rec, index) => (
                    <div key={index} className="flex items-center space-x-2 text-sm text-emerald-700">
                      <Check className="w-4 h-4" />
                      <span>{rec}</span>
                    </div>
                  ))}
                </div>
              )}

              {/* Warnings */}
              {item.warnings.length > 0 && (
                <div className="mb-4 space-y-1">
                  {item.warnings.map((warning, index) => (
                    <div key={index} className="flex items-center space-x-2 text-sm text-red-700">
                      <AlertTriangle className="w-4 h-4" />
                      <span>{warning}</span>
                    </div>
                  ))}
                </div>
              )}

              {/* Nutrition Info */}
              <div className="bg-gray-50 p-3 rounded-lg mb-4">
                <h4 className="text-sm font-medium text-gray-900 mb-2">Nutrition Facts</h4>
                <div className="grid grid-cols-2 gap-2 text-xs text-gray-600">
                  <div>Calories: {item.nutritionInfo.calories}</div>
                  <div>Protein: {item.nutritionInfo.protein}g</div>
                  <div>Carbs: {item.nutritionInfo.carbs}g</div>
                  <div>Sodium: {item.nutritionInfo.sodium}mg</div>
                </div>
              </div>

              {/* Add to Cart Button */}
              <button
                onClick={() => addToCart(item)}
                disabled={item.warnings.length > 0}
                className={`w-full py-3 rounded-lg font-semibold transition-colors flex items-center justify-center space-x-2 ${
                  item.warnings.length > 0
                    ? 'bg-gray-200 text-gray-500 cursor-not-allowed'
                    : item.isRecommended
                    ? 'bg-emerald-500 text-white hover:bg-emerald-600'
                    : 'bg-blue-500 text-white hover:bg-blue-600'
                }`}
              >
                <Plus className="w-4 h-4" />
                <span>{item.warnings.length > 0 ? 'Not Safe for You' : 'Add to Order'}</span>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}