import React from 'react';
import { useAppContext } from '../../context/AppContext';
import { Clock, CheckCircle, AlertCircle, Utensils } from 'lucide-react';

export default function OrderHistory() {
  const { state } = useAppContext();
  
  const guestOrders = state.orders.filter(order => 
    order.guestId === state.currentGuest?.id
  );

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending':
        return <Clock className="w-5 h-5 text-yellow-500" />;
      case 'preparing':
        return <Utensils className="w-5 h-5 text-blue-500" />;
      case 'ready':
        return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'delivered':
        return <CheckCircle className="w-5 h-5 text-gray-500" />;
      default:
        return <AlertCircle className="w-5 h-5 text-red-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'preparing':
        return 'bg-blue-100 text-blue-800';
      case 'ready':
        return 'bg-green-100 text-green-800';
      case 'delivered':
        return 'bg-gray-100 text-gray-800';
      default:
        return 'bg-red-100 text-red-800';
    }
  };

  if (guestOrders.length === 0) {
    return (
      <div className="text-center py-12">
        <Utensils className="w-16 h-16 text-gray-400 mx-auto mb-4" />
        <h3 className="text-xl font-semibold text-gray-900 mb-2">No Orders Yet</h3>
        <p className="text-gray-600">Browse our personalized menu to place your first order!</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-blue-500 to-purple-500 text-white p-6 rounded-2xl">
        <h2 className="text-2xl font-bold mb-2">Order History</h2>
        <p className="text-blue-100">Track your personalized dining experiences</p>
      </div>

      <div className="space-y-4">
        {guestOrders.map((order) => (
          <div key={order.id} className="bg-white p-6 rounded-2xl border border-gray-200 hover:shadow-lg transition-shadow">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center space-x-3">
                {getStatusIcon(order.status)}
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">
                    Order #{order.id.slice(-6)}
                  </h3>
                  <p className="text-sm text-gray-600">
                    {order.timestamp.toLocaleDateString()} at {order.timestamp.toLocaleTimeString()}
                  </p>
                </div>
              </div>
              <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(order.status)}`}>
                {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
              </span>
            </div>

            {/* Order Items */}
            {order.items.length > 0 && (
              <div className="mb-4">
                <h4 className="font-medium text-gray-900 mb-2">Items Ordered:</h4>
                <div className="space-y-2">
                  {order.items.map((item, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <img
                          src={item.imageUrl}
                          alt={item.name}
                          className="w-12 h-12 rounded-lg object-cover"
                        />
                        <div>
                          <p className="font-medium text-gray-900">{item.name}</p>
                          <p className="text-sm text-gray-600">{item.category}</p>
                        </div>
                      </div>
                      <span className="font-semibold text-gray-900">${item.price}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Special Requests */}
            {order.specialRequests && (
              <div className="mb-4">
                <h4 className="font-medium text-gray-900 mb-1">Special Requests:</h4>
                <p className="text-sm text-gray-600 bg-gray-50 p-3 rounded-lg">
                  {order.specialRequests}
                </p>
              </div>
            )}

            {/* Allergen Alerts */}
            {order.allergenAlerts.length > 0 && (
              <div className="mb-4">
                <h4 className="font-medium text-gray-900 mb-2">Safety Precautions:</h4>
                <div className="flex flex-wrap gap-2">
                  {order.allergenAlerts.map((alert, index) => (
                    <span
                      key={index}
                      className="px-3 py-1 bg-orange-100 text-orange-800 rounded-full text-sm font-medium"
                    >
                      No {alert}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Order Total */}
            <div className="border-t border-gray-200 pt-4 flex justify-between items-center">
              <div className="text-sm text-gray-600">
                Room {order.room} • {order.items.length} items
              </div>
              <div className="text-lg font-semibold text-gray-900">
                Total: ${order.items.reduce((sum, item) => sum + item.price, 0)}
              </div>
            </div>

            {/* Order Status Timeline */}
            <div className="mt-4 pt-4 border-t border-gray-200">
              <div className="flex items-center justify-between">
                <div className={`flex items-center space-x-2 ${
                  ['pending', 'preparing', 'ready', 'delivered'].indexOf(order.status) >= 0 
                    ? 'text-green-600' : 'text-gray-400'
                }`}>
                  <div className="w-2 h-2 rounded-full bg-current" />
                  <span className="text-sm">Order Received</span>
                </div>
                <div className={`flex items-center space-x-2 ${
                  ['preparing', 'ready', 'delivered'].indexOf(order.status) >= 0 
                    ? 'text-green-600' : 'text-gray-400'
                }`}>
                  <div className="w-2 h-2 rounded-full bg-current" />
                  <span className="text-sm">Preparing</span>
                </div>
                <div className={`flex items-center space-x-2 ${
                  ['ready', 'delivered'].indexOf(order.status) >= 0 
                    ? 'text-green-600' : 'text-gray-400'
                }`}>
                  <div className="w-2 h-2 rounded-full bg-current" />
                  <span className="text-sm">Ready</span>
                </div>
                <div className={`flex items-center space-x-2 ${
                  order.status === 'delivered' 
                    ? 'text-green-600' : 'text-gray-400'
                }`}>
                  <div className="w-2 h-2 rounded-full bg-current" />
                  <span className="text-sm">Delivered</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}