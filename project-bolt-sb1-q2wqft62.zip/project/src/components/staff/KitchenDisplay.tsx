import React from 'react';
import { useAppContext } from '../../context/AppContext';
import { Clock, AlertTriangle, CheckCircle, ChefHat, User } from 'lucide-react';

export default function KitchenDisplay() {
  const { state, dispatch } = useAppContext();

  const updateOrderStatus = (orderId: string, newStatus: 'pending' | 'preparing' | 'ready' | 'delivered') => {
    dispatch({
      type: 'UPDATE_ORDER_STATUS',
      payload: { id: orderId, status: newStatus }
    });

    // Add notification
    dispatch({
      type: 'ADD_NOTIFICATION',
      payload: {
        id: Date.now().toString(),
        type: 'info',
        title: 'Order Status Updated',
        message: `Order #${orderId.slice(-6)} marked as ${newStatus}`,
        timestamp: new Date(),
        dismissed: false
      }
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-100 border-yellow-300 text-yellow-800';
      case 'preparing':
        return 'bg-blue-100 border-blue-300 text-blue-800';
      case 'ready':
        return 'bg-green-100 border-green-300 text-green-800';
      case 'delivered':
        return 'bg-gray-100 border-gray-300 text-gray-800';
      default:
        return 'bg-gray-100 border-gray-300 text-gray-800';
    }
  };

  const getPriorityOrders = () => {
    return state.orders
      .filter(order => ['pending', 'preparing'].includes(order.status))
      .sort((a, b) => {
        // Priority: allergen alerts first, then by timestamp
        const aHasAllergens = a.allergenAlerts.length > 0;
        const bHasAllergens = b.allergenAlerts.length > 0;
        
        if (aHasAllergens && !bHasAllergens) return -1;
        if (!aHasAllergens && bHasAllergens) return 1;
        
        return a.timestamp.getTime() - b.timestamp.getTime();
      });
  };

  const priorityOrders = getPriorityOrders();

  return (
    <div className="space-y-6">
      {/* Kitchen Header */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-6 rounded-2xl">
        <div className="flex items-center space-x-3 mb-2">
          <ChefHat className="w-6 h-6" />
          <h2 className="text-2xl font-bold">Kitchen Display System</h2>
        </div>
        <p className="text-blue-100">Real-time order management with dietary safety integration</p>
      </div>

      {/* Active Orders Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
        {priorityOrders.map((order) => (
          <div
            key={order.id}
            className={`bg-white rounded-2xl border-2 p-6 shadow-sm ${
              order.allergenAlerts.length > 0 
                ? 'border-red-300 bg-red-50' 
                : 'border-gray-200'
            }`}
          >
            {/* Order Header */}
            <div className="flex items-start justify-between mb-4">
              <div>
                <div className="flex items-center space-x-2 mb-1">
                  <h3 className="text-lg font-bold text-gray-900">
                    Order #{order.id.slice(-6)}
                  </h3>
                  {order.allergenAlerts.length > 0 && (
                    <AlertTriangle className="w-5 h-5 text-red-500" />
                  )}
                </div>
                <div className="flex items-center space-x-2 text-sm text-gray-600">
                  <User className="w-4 h-4" />
                  <span>{order.guestName} • Room {order.room}</span>
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  {order.timestamp.toLocaleTimeString()} • {
                    Math.round((Date.now() - order.timestamp.getTime()) / 60000)
                  } min ago
                </p>
              </div>
              <span className={`px-3 py-1 rounded-full text-sm font-medium border ${getStatusColor(order.status)}`}>
                {order.status.toUpperCase()}
              </span>
            </div>

            {/* Allergen Alerts */}
            {order.allergenAlerts.length > 0 && (
              <div className="mb-4 p-3 bg-red-100 border border-red-200 rounded-lg">
                <div className="flex items-center space-x-2 mb-2">
                  <AlertTriangle className="w-4 h-4 text-red-600" />
                  <span className="font-medium text-red-800">ALLERGEN ALERT</span>
                </div>
                <div className="flex flex-wrap gap-1">
                  {order.allergenAlerts.map((allergen, index) => (
                    <span
                      key={index}
                      className="px-2 py-1 bg-red-200 text-red-800 text-xs font-medium rounded"
                    >
                      NO {allergen.toUpperCase()}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Order Items */}
            {order.items.length > 0 && (
              <div className="mb-4">
                <h4 className="font-medium text-gray-900 mb-2">Items:</h4>
                <div className="space-y-2">
                  {order.items.map((item, index) => (
                    <div key={index} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                      <span className="font-medium text-gray-900">{item.name}</span>
                      <span className="text-sm text-gray-600">x1</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Special Requests */}
            {order.specialRequests && (
              <div className="mb-4 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                <h4 className="font-medium text-yellow-800 mb-1">Special Requests:</h4>
                <p className="text-sm text-yellow-700">{order.specialRequests}</p>
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex space-x-2">
              {order.status === 'pending' && (
                <button
                  onClick={() => updateOrderStatus(order.id, 'preparing')}
                  className="flex-1 bg-blue-500 text-white py-2 rounded-lg hover:bg-blue-600 transition-colors font-medium"
                >
                  Start Preparing
                </button>
              )}
              {order.status === 'preparing' && (
                <button
                  onClick={() => updateOrderStatus(order.id, 'ready')}
                  className="flex-1 bg-green-500 text-white py-2 rounded-lg hover:bg-green-600 transition-colors font-medium"
                >
                  Mark Ready
                </button>
              )}
              {order.status === 'ready' && (
                <button
                  onClick={() => updateOrderStatus(order.id, 'delivered')}
                  className="flex-1 bg-gray-500 text-white py-2 rounded-lg hover:bg-gray-600 transition-colors font-medium"
                >
                  Mark Delivered
                </button>
              )}
            </div>

            {/* Timer */}
            <div className="mt-3 pt-3 border-t border-gray-200">
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-600">Prep Time:</span>
                <span className={`font-medium ${
                  Math.round((Date.now() - order.timestamp.getTime()) / 60000) > 15 
                    ? 'text-red-600' 
                    : 'text-gray-900'
                }`}>
                  {Math.round((Date.now() - order.timestamp.getTime()) / 60000)} min
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {priorityOrders.length === 0 && (
        <div className="text-center py-12">
          <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-900 mb-2">All Caught Up!</h3>
          <p className="text-gray-600">No pending orders in the kitchen right now.</p>
        </div>
      )}

      {/* Kitchen Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-gray-200">
          <div className="flex items-center space-x-3">
            <Clock className="w-8 h-8 text-yellow-500" />
            <div>
              <p className="text-2xl font-bold text-gray-900">
                {state.orders.filter(o => o.status === 'pending').length}
              </p>
              <p className="text-sm text-gray-600">Pending Orders</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white p-4 rounded-xl border border-gray-200">
          <div className="flex items-center space-x-3">
            <ChefHat className="w-8 h-8 text-blue-500" />
            <div>
              <p className="text-2xl font-bold text-gray-900">
                {state.orders.filter(o => o.status === 'preparing').length}
              </p>
              <p className="text-sm text-gray-600">In Progress</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white p-4 rounded-xl border border-gray-200">
          <div className="flex items-center space-x-3">
            <CheckCircle className="w-8 h-8 text-green-500" />
            <div>
              <p className="text-2xl font-bold text-gray-900">
                {state.orders.filter(o => o.status === 'ready').length}
              </p>
              <p className="text-sm text-gray-600">Ready to Serve</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white p-4 rounded-xl border border-gray-200">
          <div className="flex items-center space-x-3">
            <AlertTriangle className="w-8 h-8 text-red-500" />
            <div>
              <p className="text-2xl font-bold text-gray-900">
                {state.orders.filter(o => o.allergenAlerts.length > 0 && ['pending', 'preparing'].includes(o.status)).length}
              </p>
              <p className="text-sm text-gray-600">Allergen Alerts</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}