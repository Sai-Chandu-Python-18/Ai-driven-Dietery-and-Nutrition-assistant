import React, {useState, useEffect } from 'react';
import { useAppContext } from '../../context/AppContext';
import { Shield, AlertTriangle, CheckCircle, Camera, Bell, TrendingUp, Activity } from 'lucide-react';

export default function SafetyMonitoring() {
  const { state } = useAppContext();
  const [realTimeAlerts, setRealTimeAlerts] = useState<any[]>([]);
  const [buffetStatus, setBuffetStatus] = useState<any>(null);

  // Simulate real-time monitoring
  useEffect(() => {
    const interval = setInterval(() => {
      // Simulate random safety events
      if (Math.random() > 0.7) {
        const alerts = [
          {
            id: Date.now(),
            type: 'allergen_detected',
            severity: 'high',
            message: 'Shellfish detected in Pasta Station - Guest with shellfish allergy in vicinity',
            location: 'Buffet Station 3',
            timestamp: new Date(),
            guestAffected: 'Sarah Johnson (Room 302)'
          },
          {
            id: Date.now() + 1,
            type: 'cross_contamination',
            severity: 'medium',
            message: 'Potential gluten cross-contamination detected in salad bar',
            location: 'Salad Station',
            timestamp: new Date(),
            guestAffected: 'Michael Chen (Room 115)'
          },
          {
            id: Date.now() + 2,
            type: 'ingredient_change',
            severity: 'low',
            message: 'Menu item ingredient updated - Caesar dressing now contains anchovies',
            location: 'Kitchen',
            timestamp: new Date(),
            guestAffected: 'Multiple guests'
          }
        ];
        
        setRealTimeAlerts(prev => [alerts[Math.floor(Math.random() * alerts.length)], ...prev.slice(0, 4)]);
      }
    }, 8000);

    return () => clearInterval(interval);
  }, []);

  // Simulate buffet monitoring
  useEffect(() => {
    const updateBuffetStatus = () => {
      setBuffetStatus({
        lastScan: new Date(),
        itemsMonitored: 24,
        alertsActive: realTimeAlerts.filter(a => a.severity === 'high').length,
        complianceScore: 94,
        cameras: [
          { id: 1, location: 'Main Buffet', status: 'active', lastAlert: '2 min ago' },
          { id: 2, location: 'Salad Bar', status: 'active', lastAlert: '5 min ago' },
          { id: 3, location: 'Dessert Station', status: 'active', lastAlert: 'None' },
          { id: 4, location: 'Beverage Area', status: 'maintenance', lastAlert: '1 hour ago' }
        ]
      });
    };

    updateBuffetStatus();
    const interval = setInterval(updateBuffetStatus, 30000);
    return () => clearInterval(interval);
  }, [realTimeAlerts]);

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high':
        return 'bg-red-100 border-red-300 text-red-800';
      case 'medium':
        return 'bg-orange-100 border-orange-300 text-orange-800';
      case 'low':
        return 'bg-yellow-100 border-yellow-300 text-yellow-800';
      default:
        return 'bg-gray-100 border-gray-300 text-gray-800';
    }
  };

  const getAlertIcon = (type: string) => {
    switch (type) {
      case 'allergen_detected':
        return <AlertTriangle className="w-5 h-5 text-red-500" />;
      case 'cross_contamination':
        return <Shield className="w-5 h-5 text-orange-500" />;
      case 'ingredient_change':
        return <Bell className="w-5 h-5 text-yellow-500" />;
      default:
        return <AlertTriangle className="w-5 h-5 text-gray-500" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-red-600 to-orange-600 text-white p-6 rounded-2xl">
        <div className="flex items-center space-x-3 mb-2">
          <Shield className="w-6 h-6" />
          <h2 className="text-2xl font-bold">Safety Monitoring Center</h2>
        </div>
        <p className="text-red-100">Real-time allergen detection and safety compliance monitoring</p>
      </div>

      {/* Real-time Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white p-6 rounded-xl border border-gray-200">
          <div className="flex items-center space-x-3">
            <Activity className="w-8 h-8 text-green-500" />
            <div>
              <p className="text-2xl font-bold text-gray-900">
                {buffetStatus?.complianceScore || 94}%
              </p>
              <p className="text-sm text-gray-600">Safety Compliance</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white p-6 rounded-xl border border-gray-200">
          <div className="flex items-center space-x-3">
            <Camera className="w-8 h-8 text-blue-500" />
            <div>
              <p className="text-2xl font-bold text-gray-900">
                {buffetStatus?.cameras?.filter(c => c.status === 'active').length || 3}
              </p>
              <p className="text-sm text-gray-600">Active Cameras</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white p-6 rounded-xl border border-gray-200">
          <div className="flex items-center space-x-3">
            <AlertTriangle className="w-8 h-8 text-red-500" />
            <div>
              <p className="text-2xl font-bold text-gray-900">
                {realTimeAlerts.filter(a => a.severity === 'high').length}
              </p>
              <p className="text-sm text-gray-600">Critical Alerts</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white p-6 rounded-xl border border-gray-200">
          <div className="flex items-center space-x-3">
            <TrendingUp className="w-8 h-8 text-purple-500" />
            <div>
              <p className="text-2xl font-bold text-gray-900">
                {buffetStatus?.itemsMonitored || 24}
              </p>
              <p className="text-sm text-gray-600">Items Monitored</p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Real-time Alerts */}
        <div className="bg-white p-6 rounded-2xl border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xl font-semibold text-gray-900">Live Safety Alerts</h3>
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              <span className="text-sm text-gray-600">Live</span>
            </div>
          </div>

          <div className="space-y-4 max-h-96 overflow-y-auto">
            {realTimeAlerts.length > 0 ? (
              realTimeAlerts.map((alert) => (
                <div
                  key={alert.id}
                  className={`p-4 rounded-lg border-2 ${getSeverityColor(alert.severity)}`}
                >
                  <div className="flex items-start space-x-3">
                    {getAlertIcon(alert.type)}
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-1">
                        <p className="font-medium">{alert.message}</p>
                        <span className="text-xs opacity-75">
                          {alert.timestamp.toLocaleTimeString()}
                        </span>
                      </div>
                      <p className="text-sm opacity-75 mb-2">
                        Location: {alert.location}
                      </p>
                      <p className="text-sm font-medium">
                        Affected: {alert.guestAffected}
                      </p>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-8">
                <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-2" />
                <p className="text-gray-600">No active alerts - All systems normal</p>
              </div>
            )}
          </div>
        </div>

        {/* Camera Monitoring */}
        <div className="bg-white p-6 rounded-2xl border border-gray-200">
          <h3 className="text-xl font-semibold text-gray-900 mb-4">Camera Network Status</h3>
          
          {buffetStatus && (
            <div className="space-y-4">
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-medium text-gray-900">Last System Scan</span>
                  <span className="text-sm text-gray-600">
                    {buffetStatus.lastScan.toLocaleTimeString()}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="font-medium text-gray-900">Items Monitored</span>
                  <span className="text-sm text-gray-600">{buffetStatus.itemsMonitored}</span>
                </div>
              </div>

              <div className="space-y-3">
                {buffetStatus.cameras.map((camera: any) => (
                  <div key={camera.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className={`w-3 h-3 rounded-full ${
                        camera.status === 'active' ? 'bg-green-500' : 'bg-red-500'
                      }`}></div>
                      <div>
                        <p className="font-medium text-gray-900">{camera.location}</p>
                        <p className="text-sm text-gray-600">
                          Last Alert: {camera.lastAlert}
                        </p>
                      </div>
                    </div>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      camera.status === 'active' 
                        ? 'bg-green-100 text-green-800' 
                        : 'bg-red-100 text-red-800'
                    }`}>
                      {camera.status}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Guest Risk Assessment */}
      <div className="bg-white p-6 rounded-2xl border border-gray-200">
        <h3 className="text-xl font-semibold text-gray-900 mb-4">Current Guest Risk Assessment</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {state.guests.map((guest) => {
            const riskLevel = guest.allergens.filter(a => a.severity === 'severe').length > 0 ? 'high' :
                            guest.allergens.length > 2 ? 'medium' : 'low';
            
            return (
              <div
                key={guest.id}
                className={`p-4 rounded-lg border-2 ${
                  riskLevel === 'high' 
                    ? 'bg-red-50 border-red-200' 
                    : riskLevel === 'medium'
                    ? 'bg-orange-50 border-orange-200'
                    : 'bg-green-50 border-green-200'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-medium text-gray-900">{guest.name}</h4>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    riskLevel === 'high' 
                      ? 'bg-red-100 text-red-800' 
                      : riskLevel === 'medium'
                      ? 'bg-orange-100 text-orange-800'
                      : 'bg-green-100 text-green-800'
                  }`}>
                    {riskLevel} risk
                  </span>
                </div>
                <p className="text-sm text-gray-600 mb-2">Room {guest.room}</p>
                <div className="text-xs space-y-1">
                  <p>Allergens: {guest.allergens.length}</p>
                  <p>Health Conditions: {guest.healthConditions.length}</p>
                  <p>Severe Allergies: {guest.allergens.filter(a => a.severity === 'severe').length}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Safety Protocols */}
      <div className="bg-white p-6 rounded-2xl border border-gray-200">
        <h3 className="text-xl font-semibold text-gray-900 mb-4">Emergency Protocols</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h4 className="font-medium text-red-800 mb-3">High Severity Alert Response</h4>
            <ol className="text-sm text-gray-700 space-y-2">
              <li>1. Immediately isolate affected food items</li>
              <li>2. Notify guest and escort away from allergen source</li>
              <li>3. Alert kitchen staff and management</li>
              <li>4. Document incident in safety log</li>
              <li>5. Review and update safety protocols if needed</li>
            </ol>
          </div>
          
          <div>
            <h4 className="font-medium text-orange-800 mb-3">Cross-Contamination Prevention</h4>
            <ol className="text-sm text-gray-700 space-y-2">
              <li>1. Use dedicated utensils for allergen-free items</li>
              <li>2. Maintain separate prep areas for high-risk foods</li>
              <li>3. Regular cleaning and sanitization protocols</li>
              <li>4. Staff training on allergen handling procedures</li>
              <li>5. Clear labeling of all food items and ingredients</li>
            </ol>
          </div>
        </div>
      </div>
    </div>
  );
}