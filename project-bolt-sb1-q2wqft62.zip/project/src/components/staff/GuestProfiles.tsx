import React, { useState } from 'react';
import { useAppContext } from '../../context/AppContext';
import { Search, User, Heart, AlertTriangle, Shield, Eye } from 'lucide-react';

export default function GuestProfiles() {
  const { state } = useAppContext();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedGuest, setSelectedGuest] = useState<any>(null);

  const filteredGuests = state.guests.filter(guest =>
    guest.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    guest.room.includes(searchTerm)
  );

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'severe':
        return 'bg-red-100 text-red-800';
      case 'moderate':
        return 'bg-orange-100 text-orange-800';
      case 'mild':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-teal-600 to-green-600 text-white p-6 rounded-2xl">
        <h2 className="text-2xl font-bold mb-2">Guest Health Profiles</h2>
        <p className="text-teal-100">Manage dietary restrictions and health information for personalized service</p>
      </div>

      {/* Search */}
      <div className="bg-white p-6 rounded-2xl border border-gray-200">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Search guests by name or room number..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Guest List */}
        <div className="space-y-4">
          {filteredGuests.map((guest) => (
            <div
              key={guest.id}
              className={`bg-white p-6 rounded-2xl border-2 cursor-pointer transition-all hover:shadow-lg ${
                selectedGuest?.id === guest.id 
                  ? 'border-teal-300 bg-teal-50' 
                  : 'border-gray-200 hover:border-teal-200'
              }`}
              onClick={() => setSelectedGuest(guest)}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start space-x-4">
                  <div className="bg-teal-100 p-3 rounded-full">
                    <User className="w-6 h-6 text-teal-600" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">{guest.name}</h3>
                    <p className="text-gray-600">Room {guest.room}</p>
                    
                    <div className="flex items-center space-x-4 mt-2 text-sm">
                      <div className="flex items-center space-x-1">
                        <Heart className="w-4 h-4 text-blue-500" />
                        <span className="text-blue-600">{guest.healthConditions.length} conditions</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <AlertTriangle className="w-4 h-4 text-red-500" />
                        <span className="text-red-600">{guest.allergens.length} allergens</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Shield className="w-4 h-4 text-green-500" />
                        <span className="text-green-600">{guest.dietaryPreferences.length} preferences</span>
                      </div>
                    </div>
                  </div>
                </div>
                
                <button className="text-teal-600 hover:text-teal-800">
                  <Eye className="w-5 h-5" />
                </button>
              </div>

              {/* Quick Overview */}
              <div className="mt-4 pt-4 border-t border-gray-200">
                <div className="flex flex-wrap gap-2">
                  {guest.allergens.slice(0, 3).map((allergen, index) => (
                    <span
                      key={index}
                      className={`px-2 py-1 rounded-full text-xs font-medium ${getSeverityColor(allergen.severity)}`}
                    >
                      {allergen.name}
                    </span>
                  ))}
                  {guest.allergens.length > 3 && (
                    <span className="px-2 py-1 bg-gray-100 text-gray-600 rounded-full text-xs">
                      +{guest.allergens.length - 3} more
                    </span>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Guest Details */}
        <div className="sticky top-24">
          {selectedGuest ? (
            <div className="bg-white p-6 rounded-2xl border border-gray-200">
              <div className="flex items-center space-x-4 mb-6">
                <div className="bg-teal-100 p-3 rounded-full">
                  <User className="w-6 h-6 text-teal-600" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-gray-900">{selectedGuest.name}</h3>
                  <p className="text-gray-600">Room {selectedGuest.room}</p>
                </div>
              </div>

              {/* Health Conditions */}
              <div className="mb-6">
                <h4 className="text-lg font-semibold text-gray-900 mb-3 flex items-center space-x-2">
                  <Heart className="w-5 h-5 text-blue-500" />
                  <span>Health Conditions</span>
                </h4>
                {selectedGuest.healthConditions.length > 0 ? (
                  <div className="space-y-3">
                    {selectedGuest.healthConditions.map((condition: any) => (
                      <div key={condition.id} className="p-3 bg-blue-50 rounded-lg">
                        <p className="font-medium text-blue-900">{condition.name}</p>
                        <p className="text-sm text-blue-700 mt-1">
                          Restrictions: {condition.restrictions.join(', ')}
                        </p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-gray-500">No health conditions recorded</p>
                )}
              </div>

              {/* Allergens */}
              <div className="mb-6">
                <h4 className="text-lg font-semibold text-gray-900 mb-3 flex items-center space-x-2">
                  <AlertTriangle className="w-5 h-5 text-red-500" />
                  <span>Allergens</span>
                </h4>
                {selectedGuest.allergens.length > 0 ? (
                  <div className="space-y-2">
                    {selectedGuest.allergens.map((allergen: any) => (
                      <div key={allergen.id} className="flex items-center justify-between p-3 bg-red-50 rounded-lg">
                        <span className="font-medium text-red-900">{allergen.name}</span>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${getSeverityColor(allergen.severity)}`}>
                          {allergen.severity}
                        </span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-gray-500">No allergens recorded</p>
                )}
              </div>

              {/* Dietary Preferences */}
              <div>
                <h4 className="text-lg font-semibold text-gray-900 mb-3 flex items-center space-x-2">
                  <Shield className="w-5 h-5 text-green-500" />
                  <span>Dietary Preferences</span>
                </h4>
                {selectedGuest.dietaryPreferences.length > 0 ? (
                  <div className="flex flex-wrap gap-2">
                    {selectedGuest.dietaryPreferences.map((preference: string, index: number) => (
                      <span
                        key={index}
                        className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm font-medium"
                      >
                        {preference}
                      </span>
                    ))}
                  </div>
                ) : (
                  <p className="text-gray-500">No dietary preferences recorded</p>
                )}
              </div>

              {/* Kitchen Notes */}
              <div className="mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                <h5 className="font-medium text-yellow-800 mb-2">Kitchen Notes:</h5>
                <ul className="text-sm text-yellow-700 space-y-1">
                  {selectedGuest.allergens.filter((a: any) => a.severity === 'severe').length > 0 && (
                    <li>⚠️ SEVERE allergen alerts - use dedicated prep areas</li>
                  )}
                  {selectedGuest.healthConditions.some((c: any) => c.name.includes('Diabetes')) && (
                    <li>🍽️ Monitor sugar content and provide carb counts</li>
                  )}
                  {selectedGuest.healthConditions.some((c: any) => c.name.includes('Hypertension')) && (
                    <li>🧂 Keep sodium levels low, avoid added salt</li>
                  )}
                  <li>✅ Always verify ingredients with guest before serving</li>
                </ul>
              </div>
            </div>
          ) : (
            <div className="bg-gray-50 p-12 rounded-2xl text-center">
              <User className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Select a Guest</h3>
              <p className="text-gray-600">Choose a guest from the list to view their detailed health profile</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}