import React from 'react';
import { ChefHat as Chef, Heart, Shield, Users, ArrowRight, Utensils, Brain, Bell } from 'lucide-react';

interface LandingPageProps {
  onViewChange: (view: 'guest' | 'staff' | 'admin') => void;
}

export default function LandingPage({ onViewChange }: LandingPageProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-blue-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b border-emerald-100 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="bg-emerald-500 p-2 rounded-xl">
                <Utensils className="w-6 h-6 text-white" />
              </div>
              <h1 className="text-2xl font-bold text-gray-900">NutriGuard AI</h1>
            </div>
            <div className="flex space-x-4">
              <button
                onClick={() => onViewChange('guest')}
                className="px-6 py-2 bg-emerald-500 text-white rounded-lg hover:bg-emerald-600 transition-colors"
              >
                Guest Portal
              </button>
              <button
                onClick={() => onViewChange('staff')}
                className="px-6 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
              >
                Staff Dashboard
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center">
          <h2 className="text-5xl font-bold text-gray-900 mb-6">
            AI-Powered Dietary Assistant
            <span className="block text-emerald-600">for Hospitality Excellence</span>
          </h2>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Revolutionize guest dining experiences with personalized meal recommendations, 
            real-time allergen detection, and seamless kitchen integration.
          </p>
          <div className="flex justify-center space-x-6 mb-12">
            <button
              onClick={() => onViewChange('guest')}
              className="group bg-emerald-500 text-white px-8 py-4 rounded-xl text-lg font-semibold hover:bg-emerald-600 transition-all transform hover:scale-105 flex items-center space-x-2"
            >
              <span>Try Guest Experience</span>
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
            <button
              onClick={() => onViewChange('staff')}
              className="group bg-blue-500 text-white px-8 py-4 rounded-xl text-lg font-semibold hover:bg-blue-600 transition-all transform hover:scale-105 flex items-center space-x-2"
            >
              <span>Staff Dashboard</span>
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-20">
          <div className="text-center">
            <div className="bg-emerald-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <Heart className="w-8 h-8 text-emerald-600" />
            </div>
            <h3 className="text-3xl font-bold text-gray-900">98%</h3>
            <p className="text-gray-600">Accuracy in Allergen Detection</p>
          </div>
          <div className="text-center">
            <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <Shield className="w-8 h-8 text-blue-600" />
            </div>
            <h3 className="text-3xl font-bold text-gray-900">100%</h3>
            <p className="text-gray-600">FDA Compliance</p>
          </div>
          <div className="text-center">
            <div className="bg-amber-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <Users className="w-8 h-8 text-amber-600" />
            </div>
            <h3 className="text-3xl font-bold text-gray-900">10K+</h3>
            <p className="text-gray-600">Guests Served Daily</p>
          </div>
          <div className="text-center">
            <div className="bg-purple-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <Chef className="w-8 h-8 text-purple-600" />
            </div>
            <h3 className="text-3xl font-bold text-gray-900">500+</h3>
            <p className="text-gray-600">Partner Hotels</p>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="bg-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h3 className="text-3xl font-bold text-gray-900 mb-4">Comprehensive Health-Conscious Solutions</h3>
            <p className="text-xl text-gray-600">Advanced AI technology meets hospitality excellence</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-gradient-to-br from-emerald-50 to-emerald-100 p-8 rounded-2xl border hover:shadow-lg transition-shadow">
              <div className="bg-emerald-500 w-12 h-12 rounded-xl flex items-center justify-center mb-6">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <h4 className="text-xl font-semibold text-gray-900 mb-4">AI-Powered Recommendations</h4>
              <p className="text-gray-600">Personalized meal suggestions based on health conditions, dietary restrictions, and preferences using advanced machine learning.</p>
            </div>

            <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-8 rounded-2xl border hover:shadow-lg transition-shadow">
              <div className="bg-blue-500 w-12 h-12 rounded-xl flex items-center justify-center mb-6">
                <Shield className="w-6 h-6 text-white" />
              </div>
              <h4 className="text-xl font-semibold text-gray-900 mb-4">Real-Time Allergen Detection</h4>
              <p className="text-gray-600">Computer vision technology scans buffet items and menu ingredients to prevent allergic reactions before they happen.</p>
            </div>

            <div className="bg-gradient-to-br from-amber-50 to-amber-100 p-8 rounded-2xl border hover:shadow-lg transition-shadow">
              <div className="bg-amber-500 w-12 h-12 rounded-xl flex items-center justify-center mb-6">
                <Bell className="w-6 h-6 text-white" />
              </div>
              <h4 className="text-xl font-semibold text-gray-900 mb-4">Instant Safety Alerts</h4>
              <p className="text-gray-600">Push notifications and visual alerts keep guests and staff informed of potential dietary conflicts in real-time.</p>
            </div>

            <div className="bg-gradient-to-br from-purple-50 to-purple-100 p-8 rounded-2xl border hover:shadow-lg transition-shadow">
              <div className="bg-purple-500 w-12 h-12 rounded-xl flex items-center justify-center mb-6">
                <Chef className="w-6 h-6 text-white" />
              </div>
              <h4 className="text-xl font-semibold text-gray-900 mb-4">Kitchen Integration</h4>
              <p className="text-gray-600">Seamless integration with kitchen display systems for real-time dietary requirement tracking and order management.</p>
            </div>

            <div className="bg-gradient-to-br from-rose-50 to-rose-100 p-8 rounded-2xl border hover:shadow-lg transition-shadow">
              <div className="bg-rose-500 w-12 h-12 rounded-xl flex items-center justify-center mb-6">
                <Heart className="w-6 h-6 text-white" />
              </div>
              <h4 className="text-xl font-semibold text-gray-900 mb-4">Health Condition Support</h4>
              <p className="text-gray-600">Specialized meal recommendations for diabetes, hypertension, celiac disease, and other health conditions.</p>
            </div>

            <div className="bg-gradient-to-br from-teal-50 to-teal-100 p-8 rounded-2xl border hover:shadow-lg transition-shadow">
              <div className="bg-teal-500 w-12 h-12 rounded-xl flex items-center justify-center mb-6">
                <Users className="w-6 h-6 text-white" />
              </div>
              <h4 className="text-xl font-semibold text-gray-900 mb-4">Guest Profile Management</h4>
              <p className="text-gray-600">Comprehensive dietary profiles that follow guests throughout their stay and future visits for consistent care.</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gradient-to-r from-emerald-600 to-blue-600 py-20">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h3 className="text-3xl font-bold text-white mb-6">
            Ready to Transform Your Guest Experience?
          </h3>
          <p className="text-xl text-emerald-100 mb-8">
            Join leading hotels worldwide in providing safer, more personalized dining experiences.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={() => onViewChange('guest')}
              className="bg-white text-emerald-600 px-8 py-4 rounded-xl font-semibold hover:bg-gray-100 transition-colors"
            >
              Experience Guest Portal
            </button>
            <button
              onClick={() => onViewChange('admin')}
              className="bg-emerald-500 text-white px-8 py-4 rounded-xl font-semibold hover:bg-emerald-400 transition-colors border-2 border-white/20"
            >
              Request Demo
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="bg-emerald-500 p-2 rounded-xl">
                <Utensils className="w-6 h-6 text-white" />
              </div>
              <span className="text-xl font-semibold">NutriGuard AI</span>
            </div>
            <p className="text-gray-400">© 2025 NutriGuard AI. Revolutionizing hospitality dining.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}